const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    guildId: { type: String, required: true },
    xp: { type: Number, default: 0 },
    level: { type: Number, default: 0 },
    warns: { type: Number, default: 0 },
    bans: { type: Number, default: 0 },
    kicks: { type: Number, default: 0 },
    timeouts: { type: Number, default: 0 },
    note: { type: String, default: '' },
    warnings: [{
        reason: { type: String, default: '' },
        date: { type: Date, default: Date.now },
        moderatorId: { type: String, default: '' }
    }],
    totalMessages: { type: Number, default: 0 },
    birthday: Date,
    messages: [{
        content: { type: String, required: false },
        timeSent: { type: Number, default: Date.now }
    }],
    tempBans: [{
        endTime: { type: Date, required: true },
        reason: { type: String, default: '' },
        moderatorId: { type: String, default: '' },
        lifted: { type: Boolean, default: false }
    }]
});

module.exports = mongoose.model('UserData', UserSchema);