const { ActivityType, Discord, EmbedBuilder, ChannelType } = require('discord.js');

const fs = require('fs');
const yaml = require("js-yaml");
const moment = require('moment-timezone');
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'));
const colors = require('ansi-colors');
const packageFile = require('../package.json');
const GuildData = require('../models/guildDataSchema');
const UserData = require('../models/UserData');
const { handleVerification, createUnverifiedRoleIfNeeded } = require('../events/Verification/VerificationEvent')
const Verification = require('../models/verificationSchema')
const botStartTime = Date.now();

module.exports = async client => {

    client.guilds.cache.forEach(async guild => {
        try {
            let verificationData = await Verification.findOne({ guildID: guild.id });
            if (!verificationData) {
                verificationData = new Verification({
                    guildID: guild.id,
                    msgID: null,
                    unverifiedRoleID: null
                });
                await verificationData.save();
            }

            await createUnverifiedRoleIfNeeded(guild, verificationData);

            await handleVerification(client, guild);
        } catch (error) {
            console.error(`Failed to initialize verification for guild ${guild.id}: ${error}`);
        }
    });


    if (packageFile.version !== config.Version) {
        console.log('\x1b[31m%s\x1b[0m', `[ERROR] Your config.yml file is outdated!`);
        process.exit();
    }

    let guild = client.guilds.cache.get(config.GuildID);
    if (!guild) {
        console.log('\x1b[31m%s\x1b[0m', `[ERROR] The guild ID specified in the config is invalid or the bot is not in the server!`);
        process.exit();
    }

    let guildData = await GuildData.findOne({ guildID: guild.id });
    if (!guildData) {
        guildData = new GuildData({
            guildID: guild.id,
            cases: 0,
            totalMessages: 0,
            stars: {},
            birthday: null,
            totalSuggestions: 0,
            timesBotStarted: 1
        });
        await guildData.save();
    } else {
        guildData.timesBotStarted++;
        await guildData.save();
    }

    let verificationData = await Verification.findOne({ guildID: guild.id });
    if (!verificationData) {
        verificationData = new Verification({
            guildID: guild.id,
            msgID: null,
            unverifiedRoleID: null
        });
        await verificationData.save();
    }


    if (config.EnableReactionRoles) {
        config.ReactionRoles.forEach(async r => {
            let channel = await guild.channels.cache.get(r.channelID)
            let role = guild.roles.cache.get(r.roleID);
            if (!channel) console.log('\x1b[31m%s\x1b[0m', `[ERROR] config.ReactionRoles.channelID is not a valid channel! (${r.channelID})`)
            if (!role) console.log('\x1b[31m%s\x1b[0m', `[ERROR] config.ReactionRoles.roleID is not a valid role! (${r.roleID})`)
            if (channel && role) {
                let meHoist = guild.members.cache.find(m => m.user.id == client.user.id).roles.highest.rawPosition;
                let theHoist = role.rawPosition;
                if (theHoist > meHoist) await console.log('\x1b[31m%s\x1b[0m', `[ERROR] The bot's role has to be above all the reaction roles! (${role.name})`)

                let msg = await channel.messages.fetch(`${r.messageID}`).catch(e => { })
                if (msg !== undefined) {
                    try {
                        await msg.react(`${r.emojiName}`)
                    } catch (e) { }
                }
            }
        });
    }
 
 
    function getUptime() {
        const duration = moment.duration(client.uptime);
        return `${duration.hours()}h ${duration.minutes()}m ${duration.seconds()}s`;
      }
      
      async function updateBotActivity(index) {
        try {
          const guild = client.guilds.cache.get(config.GuildID);
          if (!guild) {
            console.log(`Guild not found for ID: ${config.GuildID}`);
            return;
          }
      
          let guildData = await GuildData.findOne({ guildID: guild.id });
          if (!guildData) {
            console.log(`Guild data not found for guild ID: ${guild.id}`);
            return;
          }
      
          if (index < 0 || index >= config.BotActivitySettings.Statuses.length) {
            console.log(`Invalid status index: ${index}`);
            return;
          }
      
          const totalChannels = guild.channels.cache.filter(channel =>
              channel.type === ChannelType.GuildText || channel.type === ChannelType.GuildVoice
          ).size;
      
          const onlineMembers = guild.members.cache.filter(member =>
              ['online', 'idle', 'dnd'].includes(member.presence?.status)
          ).size;
      
          const uptime = getUptime();
      
          const activityString = config.BotActivitySettings.Statuses[index]
              .replace(/{total-users}/g, `${guild.memberCount}`)
              .replace(/{total-channels}/g, `${totalChannels}`)
              .replace(/{total-messages}/g, `${guildData.totalMessages}`)
              .replace(/{online-members}/g, `${onlineMembers}`)
              .replace(/{uptime}/g, `${uptime}`)
              .replace(/{total-boosts}/g, `${guild.premiumSubscriptionCount}`)
              .replace(/{total-cases}/g, `${guildData.cases}`)
              .replace(/{total-suggestions}/g, `${guildData.totalSuggestions}`)
              .replace(/{times-bot-started}/g, `${guildData.timesBotStarted}`);
      
          let activityType;
          switch (config.BotActivitySettings.ActivityType.toUpperCase()) {
            case "WATCHING":
              activityType = ActivityType.Watching;
              break;
            case "PLAYING":
              activityType = ActivityType.Playing;
              break;
            case "COMPETING":
              activityType = ActivityType.Competing;
              break;
            case "STREAMING":
              activityType = ActivityType.Streaming;
              break;
            case "CUSTOM":
              activityType = ActivityType.Custom;
            break;
            default:
              console.log(`Invalid Activity Type: ${config.BotActivitySettings.ActivityType}`);
              activityType = ActivityType.Custom;
          }
      
          const presenceOptions = {
            activities: [{ name: activityString, type: activityType }],
            status: config.BotActivitySettings.Status,
          };
      
          if (activityType === ActivityType.Streaming && config.BotActivitySettings.StreamingURL) {
            presenceOptions.activities[0].url = config.BotActivitySettings.StreamingURL;
          }
      
          await client.user.setPresence(presenceOptions);
        } catch (error) {
          console.error('Error updating bot activity:', error);
        }
      }

    if (config.BotActivitySettings.Enabled) {
        let index = 0;
        updateBotActivity(index);
        setInterval(() => {
            index = (index + 1) % config.BotActivitySettings.Statuses.length;
            updateBotActivity(index);
        }, config.BotActivitySettings.Interval * 1000);
    }

    client.guilds.cache.forEach(guild => {
        if (!config.GuildID.includes(guild.id)) {
            guild.leave();
            console.log('\x1b[31m%s\x1b[0m', `[INFO] Someone tried to invite the bot to another server! I automatically left it (${guild.name})`)
        }
    })


    if (guild && !guild.members.me.permissions.has("Administrator")) {
        console.log('\x1b[31m%s\x1b[0m', `[ERROR] The bot doesn't have enough permissions! Please give the bot ADMINISTRATOR permissions in your server or it won't function properly!`)
    }

    async function updateChannelStats(client) {
        const guild = client.guilds.cache.get(config.GuildID);
        if (!guild) {
            console.log("Guild not found or not specified in the config.");
            return;
        }

        async function updateChannel(channelID, channelNameTemplate, value) {
            const channel = guild.channels.cache.get(channelID);
            if (channel && channel.type === ChannelType.GuildVoice) {
                const newName = channelNameTemplate.replace(/{.+?}/g, value);
                await channel.setName(newName).catch(error => console.error(`Error updating channel: ${channelID}`, error));
            } else {
                console.log(`You need to use voice channels for Channel Stats: ${channelID}`);
            }
        }
        if (config.MemberCount.Enabled) {
            await updateChannel(config.MemberCount.ChannelID, config.MemberCount.ChannelName, guild.memberCount.toString());
        }
        if (config.NitroBoosterCount.Enabled) {
            await updateChannel(config.NitroBoosterCount.ChannelID, config.NitroBoosterCount.ChannelName, guild.premiumSubscriptionCount.toString());
        }
        if (config.ServerCreationDate.Enabled) {
            const creationDate = guild.createdAt.toDateString();
            await updateChannel(config.ServerCreationDate.ChannelID, config.ServerCreationDate.ChannelName, creationDate);
        }
        if (config.TotalRolesCount.Enabled) {
            const totalRoles = guild.roles.cache.size.toString();
            await updateChannel(config.TotalRolesCount.ChannelID, config.TotalRolesCount.ChannelName, totalRoles);
        }
        if (config.TotalEmojisCount.Enabled) {
            const totalEmojis = guild.emojis.cache.size.toString();
            await updateChannel(config.TotalEmojisCount.ChannelID, config.TotalEmojisCount.ChannelName, totalEmojis);
        }
        if (config.TotalChannelsCount.Enabled) {
            const totalChannels = guild.channels.cache.size.toString();
            await updateChannel(config.TotalChannelsCount.ChannelID, config.TotalChannelsCount.ChannelName, totalChannels);
        }

        if (config.OnlineMembersCount.Enabled) {
            const onlineMembers = guild.members.cache.filter(member => member.presence?.status === 'online').size.toString();
            await updateChannel(config.OnlineMembersCount.ChannelID, config.OnlineMembersCount.ChannelName, onlineMembers);
        }

        if (config.ServerRegion.Enabled) {
            const serverRegion = guild.preferredLocale;
            await updateChannel(config.ServerRegion.ChannelID, config.ServerRegion.ChannelName, serverRegion);
        }

        if (config.TotalBannedMembers.Enabled) {
            const bans = await guild.bans.fetch();
            const totalBans = bans.size.toString();
            await updateChannel(config.TotalBannedMembers.ChannelID, config.TotalBannedMembers.ChannelName, totalBans);
        }
    }

    async function birthday(guild) {
        if (config.BirthdaySystem.Enabled) {
            const timezone = config.Timezone || 'America/New_York';
            const todayFormatted = moment().tz(timezone).format('MMMM D');

            const users = await UserData.find({ guildId: guild.id });

            const birthdayUsers = users.filter(u => {
                const userBirthdayFormatted = moment(u.birthday).tz(timezone).format('MMMM D');
                return todayFormatted === userBirthdayFormatted;
            });

            if (birthdayUsers.length > 0) {
                const embed = new EmbedBuilder()
                    .setTitle(config.BirthdaySystem.MessageTitle)
                    .setColor(config.EmbedColors)
                    .setDescription(`${config.BirthdaySystem.Message}\n\n${birthdayUsers.map(u => `<@!${u.userId}>`).join(' ')}`);

                let channel = guild.channels.cache.get(config.BirthdaySystem.ChannelID);
                if (channel) {
                    channel.send({ embeds: [embed] });
                }
            }
        }
    }

    setInterval(() => {
        birthday(client);
        updateChannelStats(client);
    }, 300000);

    try {
        logStartupMessages(client);
    } catch (error) {
        console.error('An error occurred:', error);
    }
};

async function logStartupMessages(client) {
    try {
        const guild = client.guilds.cache.get(config.GuildID);
        const updatedGuildData = await GuildData.findOne({ guildID: guild.id });

        console.log("――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――");
        console.log("                                                                          ");
        if (config.LicenseKey) {
            console.log(`${colors.green(colors.bold(`Drako Bot v${packageFile.version} is now Online!`))} (${colors.gray(`${config.LicenseKey.slice(0, -10)}`)})`);
        } else {
            console.log(`${colors.green(colors.bold(`Drako Bot v${packageFile.version} is now Online!`))}`);
        }
        console.log("                                                                          ");
        console.log(`• Join our discord server for support: ${colors.green(`http://discord.drakodevelopment.net`)}`);
        console.log(`• By using this bot you agree to all terms located here: ${colors.blue(`https://wiki.drakodevelopment.net/tos`)}`);
        console.log(`• Addons for the bot can be purchased through the discord: ${colors.red(`http://discord.drakodevelopment.net`)}`);
        if (config.Statistics) {
            console.log("                                                                          ");
            console.log(`${colors.green.bold.underline(`Statistics:`)}`);
            console.log(`• The bot has been started a total of ${colors.cyan.underline(`${updatedGuildData.timesBotStarted.toLocaleString('en-US')}`)} times.`);
            console.log(`• A total of ${colors.cyan.underline(`${updatedGuildData.totalMessages.toLocaleString('en-US')}`)} messages have been sent.`);
            console.log(`• A total of ${colors.cyan.underline(`${updatedGuildData.totalSuggestions.toLocaleString('en-US')}`)} suggestions have been submitted.`);
        }
        if (config.LicenseKey) {
            console.log("                                                                          ");
            console.log(`${colors.green.bold.underline(`Source Code:`)}`);
            console.log(`• You can buy the full source code in the discord: ${colors.yellow(`http://discord.drakodevelopment.net`)}`);
        }
        console.log("                                                                          ");
        console.log("――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――");

        let logMsg = `\n\n[${new Date().toLocaleString()}] [READY] Bot is now ready!`;
        fs.appendFile("./logs.txt", logMsg, (e) => {
            if (e) console.log(e);
        });

        await GuildData.findOneAndUpdate(
            { guildID: guild.id },
            { $inc: { timesBotStarted: 1 } },
            { new: true, upsert: true }
        );

        if (updatedGuildData.timesBotStarted === 1) {
            console.log(``);
            console.log(`Thank you for choosing ${colors.cyan('Drako Bot')}!`);
            console.log(`Since this is your first time starting the bot, Here is some important information:`);
            console.log(``);
            console.log(`If you need any help, Create a ticket in our discord server.`);
            console.log(`You can also look at our documentation for help, ${colors.cyan(`https://wiki.drakodevelopment.net/docs`)}`);
            console.log(``);
            console.log(`Remember to ${colors.bold.red(`never`)} delete the "data" folder\nDeleting this folder will reset all stored data, including but not limited to: user data, suggestions, statistics, tickets, leveling, leaderboards`);
            console.log(``);
            console.log(`${colors.bold.red(`Leaking or redistributing any of our products is not allowed \nif you are found doing it, your license will be permanently disabled!`)}`);
            console.log(`By using this bot you agree to all terms located here, ${colors.cyan(`https://wiki.drakodevelopment.net/tos`)}`);
        }
    } catch (error) {
        console.error('An error occurred:', error);
    }
}