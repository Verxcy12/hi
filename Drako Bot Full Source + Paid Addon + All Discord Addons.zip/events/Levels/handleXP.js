const { EmbedBuilder, ChannelType } = require('discord.js');
const ms = require('ms');
const UserData = require('../../models/UserData');
const fs = require('fs');
const yaml = require("js-yaml");
const configPath = '././config.yml';
let config;

try {
    config = yaml.load(fs.readFileSync(configPath, 'utf8'));
} catch (err) {
    console.error(`Failed to load configuration from ${configPath}:`, err);
    process.exit(1);
}

const xpCooldown = new Map();

async function handleXP(message) {
    if (!message || !message.guild) {
        console.warn("Received an invalid message or missing guild");
        return;
    }

    if (!config.LevelingSystem || !config.CommandsPrefix) {
        console.error("Missing necessary configuration for Leveling System or Commands Prefix");
        return;
    }

    if (!config.LevelingSystem.Enabled || message.author.bot || message.content.startsWith(config.CommandsPrefix) || config.LevelingSystem.DisabledChannels?.includes(message.channel.id)) {
        return;
    }

    if (config.LevelingSystem.EnableXPCooldown) {
        const cooldownAmount = ms(config.LevelingSystem.XPCooldown || "20s");
        const currentTime = Date.now();
        const userCooldown = xpCooldown.get(message.author.id);

        if (userCooldown && currentTime < userCooldown + cooldownAmount) {
            return;
        }

        xpCooldown.set(message.author.id, currentTime);
        setTimeout(() => xpCooldown.delete(message.author.id), cooldownAmount);
    }

    let userData = await UserData.findOne({ userId: message.author.id, guildId: message.guild.id }) || new UserData({ userId: message.author.id, guildId: message.guild.id, xp: 0, level: 0, totalMessages: 0 });

    const xpToAdd = Math.floor(Math.random() * (config.LevelingSystem.MaxXP - config.LevelingSystem.MinXP + 1)) + config.LevelingSystem.MinXP;
    if (isNaN(xpToAdd) || xpToAdd <= 0) {
        console.error("Invalid XP configuration");
        return;
    }

    userData.xp += xpToAdd;
    const xpNeeded = userData.level === 0 ? 70 : userData.level * config.LevelingSystem.XPNeeded;
    if (userData.xp >= xpNeeded) {
        userData.level++;
        userData.xp = 0;
        const levelUpChannelId = config.LevelingSystem.LevelUpChannelID || message.channel.id;
        const channel = message.guild.channels.cache.get(levelUpChannelId);

        if (!channel || channel.type !== ChannelType.GuildText) {
            console.error("Level-up channel not found");
            return;
        }

        if (config.LevelingSystem.UseEmbed) {
            const embed = new EmbedBuilder();
            embed.setColor(config.LevelingSystem.Embed.Color || '#34eb6b');

            if (config.LevelingSystem.Embed.Title) {
                embed.setTitle(config.LevelingSystem.Embed.Title.replace('{userName}', message.author.username).replace('{level}', userData.level.toString()));
            }

            if (config.LevelingSystem.Embed.Description && config.LevelingSystem.Embed.Description.length > 0) {
                const description = config.LevelingSystem.Embed.Description.join('\n')
                    .replace('{userName}', message.author.username)
                    .replace('{level}', userData.level.toString())
                    .replace('{guildName}', message.guild.name)
                    .replace('{memberCount}', message.guild.memberCount.toString());
                embed.setDescription(description);
            }

            if (config.LevelingSystem.Embed.Footer) {
                embed.setFooter({
                    text: config.LevelingSystem.Embed.Footer.replace('{userName}', message.author.username).replace('{level}', userData.level.toString()), // Added replacement for `{level}`
                    iconURL: config.LevelingSystem.Embed.FooterIconURL || undefined
                });
            }

            if (config.LevelingSystem.Embed.Thumbnail) {
                embed.setThumbnail(message.author.displayAvatarURL());
            }

            if (config.LevelingSystem.Embed.Footer) {
                embed.setFooter({ text: config.LevelingSystem.Embed.Footer.replace('{userName}', message.author.username), iconURL: config.LevelingSystem.Embed.FooterIconURL || undefined });
            }

            if (config.LevelingSystem.Embed.Image) {
                embed.setImage(config.LevelingSystem.Embed.Image);
            }

            channel.send({ embeds: [embed] });
        } else {
            const levelUpMessage = removeTags(config.LevelingSystem.LevelUpMessage.replace('{user}', message.author.toString()).replace('{level}', userData.level.toString()));
            if (levelUpMessage.trim() !== "") {
                channel.send(levelUpMessage);
            }
        }
    }

    await userData.save();
}

function removeTags(text) {
    text = text.replace(/@everyone/gi, "everyone").replace(/@here/gi, "here");
    text = text.replace(/<@&\d+>/g, "(role mention removed)");
    return text;
}


module.exports = handleXP;