const { Client, PermissionFlagsBits, ButtonBuilder, ActionRowBuilder, EmbedBuilder, ButtonStyle, ChannelType } = require('discord.js');
const yaml = require("js-yaml");
const fs = require('fs');
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'));
const Verification = require('../../models/verificationSchema');

async function createUnverifiedRoleIfNeeded(guild, verificationData) {
    if (!config.VerificationSettings.EnableUnverifiedRole) {
        return;
    }

    if (verificationData.unverifiedRoleID) {
        const existingRole = guild.roles.cache.get(verificationData.unverifiedRoleID);
        if (existingRole) {
            return;
        } else {
        }
    }

    try {
        const unverifiedRole = await guild.roles.create({
            name: 'Unverified',
            color: '#FF5733',
            permissions: [],
            reason: 'Role for unverified members'
        });

        const verificationChannelID = config.VerificationSettings.ChannelID;
        guild.channels.cache.forEach(async (channel) => {
            if (channel.type === ChannelType.GuildText || channel.type === ChannelType.GuildVoice) {
                if (channel.id === verificationChannelID) {
                    await channel.permissionOverwrites.create(unverifiedRole, {
                        ViewChannel: true
                    }).catch(console.error);
                } else {
                    await channel.permissionOverwrites.create(unverifiedRole, {
                        ViewChannel: false
                    }).catch(console.error);
                }
            }
        });

        verificationData.unverifiedRoleID = unverifiedRole.id;
        await verificationData.save();
    } catch (error) {
        console.error(`[ERROR] Failed to create unverified role in guild ${guild.id}: `, error);
    }
}




async function sendOrUpdateVerificationMessage(channel, verificationData) {
    let buttonStyle;

    switch (config.VerificationButton.Color.toLowerCase()) {
        case "primary":
            buttonStyle = ButtonStyle.Primary;
            break;
        case "secondary":
            buttonStyle = ButtonStyle.Secondary;
            break;
        case "success":
            buttonStyle = ButtonStyle.Success;
            break;
        case "danger":
            buttonStyle = ButtonStyle.Danger;
            break;
        default:
            buttonStyle = ButtonStyle.Secondary;
    }

    const button = new ButtonBuilder()
        .setCustomId('verifyButton')
        .setLabel(config.VerificationButton.Name)
        .setStyle(buttonStyle)
        .setEmoji(config.VerificationButton.Emoji);

    const row = new ActionRowBuilder().addComponents(button);

    const verifEmbed = new EmbedBuilder()
        .setTitle(config.VerificationEmbed.Title)
        .setColor(config.EmbedColors)
        .setDescription(config.VerificationEmbed.Description);

    if (config.VerificationEmbed.Image && config.VerificationEmbed.Image.trim() !== '') {
        verifEmbed.setImage(config.VerificationEmbed.Image);
    }

    try {
        let message;
        if (verificationData.msgID) {
            message = await channel.messages.fetch(verificationData.msgID).catch(() => null);
            if (message) {
                const isEmbedSame = message.embeds[0] && message.embeds[0].title === verifEmbed.data.title && message.embeds[0].description === verifEmbed.data.description;
                const isButtonSame = message.components[0] && message.components[0].components[0].label === button.data.label;

                if (isEmbedSame && isButtonSame) {
                    return;
                } else {
                    await message.edit({ embeds: [verifEmbed], components: [row] });
                    return;
                }
            }
        }
        message = await channel.send({ embeds: [verifEmbed], components: [row] });
        verificationData.msgID = message.id;
        await verificationData.save();
    } catch (error) {
        console.error(`[ERROR] Failed to send or update verification message: `, error);
    }
}



async function handleVerification(client, guild) {
    try {
        let verificationData = await Verification.findOne({ guildID: guild.id });
        if (!verificationData) {
            verificationData = await new Verification({ guildID: guild.id }).save();
        }

        const channel = guild.channels.cache.get(config.VerificationSettings.ChannelID);
        if (!channel) {
            return;
        }

        await sendOrUpdateVerificationMessage(channel, verificationData);
    } catch (error) {
        console.log(error)
    }
}


async function handleVerificationInteraction(client, interaction) {
    if (!interaction.isButton() || interaction.customId !== 'verifyButton') {
        return;
    }

    try {
        if (interaction.deferred || interaction.replied) {
            return;
        }

        await interaction.deferReply({ ephemeral: true });

        const member = interaction.member;
        const isAlreadyVerified = config.VerificationSettings.VerifiedRoleID.some(roleID => member.roles.cache.has(roleID));

        if (isAlreadyVerified) {
            await interaction.editReply({ content: 'You are already verified!', ephemeral: true });
            return;
        }

        await member.roles.add(config.VerificationSettings.VerifiedRoleID).catch(error => {
            if (error.code === 10011) {
                console.error(`Unknown Role: The role ID [${config.VerificationSettings.VerifiedRoleID}] does not exist.`);
            } else {
                console.error('Error adding verified roles:', error);
            }
        });

        let verificationData = await Verification.findOne({ guildID: member.guild.id });
        if (verificationData && verificationData.unverifiedRoleID) {
            await member.roles.remove(verificationData.unverifiedRoleID).catch(error => {
                if (error.code === 10011) {
                    console.error(`Unknown Role: The role ID [${verificationData.unverifiedRoleID}] set as unverifiedRoleID does not exist.`);
                    interaction.editReply({ content: 'The unverified role configured in the server does not exist. Please contact the server administrator.', ephemeral: true });
                } else {
                    console.error('Error removing unverified role:', error);
                }
            });
        }

        if (config.JoinRoleSettings.Enabled) {
            await member.roles.add(config.JoinRoleSettings.JoinRoles).catch(console.error);
        }

        if (config.VerificationSettings.RoleToRemove) {
            await member.roles.remove(config.VerificationSettings.RoleToRemove).catch(console.error);
        }

        await interaction.editReply({ content: 'You have been successfully verified!', ephemeral: true });
    } catch (error) {
        console.error('Error during verification process:', error);
        await interaction.editReply({ content: 'There was an error verifying your account. Please contact server staff.', ephemeral: true });
    }
}

module.exports = { handleVerification, createUnverifiedRoleIfNeeded, handleVerificationInteraction };