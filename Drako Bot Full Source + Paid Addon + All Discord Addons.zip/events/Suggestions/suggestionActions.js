const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ChannelType
} = require('discord.js');
const yaml = require('js-yaml');
const fs = require('fs');
const Suggestion = require('../../models/Suggestion');
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'));
const lang = yaml.load(fs.readFileSync('./lang.yml', 'utf8'))
const GuildData = require('../../models/guildDataSchema');

const formatLongTime = () => {
    const date = new Date();
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
};

const formatShortTime = () => {
    return new Date().toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
    });
};

const toTitleCase = (str) => {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};

const mapButtonColor = (color) => {
    if (!color) return ButtonStyle.Primary;
    const normalizedColor = toTitleCase(color);
    return ButtonStyle[normalizedColor] || ButtonStyle.Primary;
};

const generateUniqueId = async () => {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result;
    let isUnique = false;
    while (!isUnique) {
        result = '';
        for (let i = 0; i < 5; i++) {
            result += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        const existingSuggestion = await Suggestion.findOne({
            uniqueId: result
        });
        if (!existingSuggestion) {
            isUnique = true;
        }
    }
    return result;
};

const updateSuggestionEmbed = async (client, suggestionId) => {
    try {
        const updatedSuggestion = await Suggestion.findById(suggestionId);
        if (!updatedSuggestion) throw new Error('Updated suggestion not found.');

        const channel = client.channels.cache.get(updatedSuggestion.channelId);
        const message = await channel.messages.fetch(updatedSuggestion.messageId);
        if (!message) throw new Error('Message not found.');
        const oldEmbed = message.embeds[0];
        if (!oldEmbed) throw new Error('Embed not found.');
        const embedDescriptionTemplate = config.SuggestionEmbed.EmbedDescription;

        const updatedDescription = embedDescriptionTemplate.map(line =>
            line.replace(/{upvotecount}/gi, updatedSuggestion.upvotes.toString())
                .replace(/{downvotecount}/gi, updatedSuggestion.downvotes.toString())
                .replace(/{suggestion}/gi, updatedSuggestion.text)
        ).join('\n');

        const newEmbed = new EmbedBuilder(oldEmbed)
            .setDescription(updatedDescription);

        await message.edit({
            embeds: [newEmbed]
        });
    } catch (error) {
        console.error('Error updating suggestion embed:', error);
    }
};



async function createSuggestion(client, interaction, suggestionText) {
    try {
        await interaction.deferReply({ ephemeral: true });

        const suggestionSettings = config.SuggestionSettings;
        const suggestionChannelId = suggestionSettings.ChannelID.match(/^\d+$/) ? suggestionSettings.ChannelID : null;

        if (!suggestionChannelId) {
            await interaction.editReply({ content: 'Suggestion channel is not configured.' });
            return;
        }

        const suggestionChannel = client.channels.cache.get(suggestionChannelId);
        const userIconUrl = interaction.user.displayAvatarURL();
        const uniqueId = await generateUniqueId();

        const embed = new EmbedBuilder()
            .setColor(config.SuggestionEmbed.EmbedColor)
            .setTitle(replacePlaceholders(config.SuggestionEmbed.EmbedTitle, interaction, suggestionText, uniqueId))
            .setDescription(replacePlaceholders(config.SuggestionEmbed.EmbedDescription.join('\n'), interaction, suggestionText, uniqueId));

        if (config.SuggestionEmbed.Thumbnail && userIconUrl) {
            embed.setThumbnail(userIconUrl);
        }

        const embedFooterText = replacePlaceholders(config.SuggestionEmbed.EmbedFooter, interaction, suggestionText, uniqueId);
        embed.setFooter({ text: embedFooterText, iconURL: userIconUrl || undefined });

        const upvoteButton = new ButtonBuilder()
            .setCustomId(`upvote-${uniqueId}`)
            .setLabel(config.SuggestionUpvote.ButtonName)
            .setEmoji(config.SuggestionUpvote.ButtonEmoji)
            .setStyle(mapButtonColor(config.SuggestionUpvote.ButtonColor));

        const downvoteButton = new ButtonBuilder()
            .setCustomId(`downvote-${uniqueId}`)
            .setLabel(config.SuggestionDownvote.ButtonName)
            .setEmoji(config.SuggestionDownvote.ButtonEmoji)
            .setStyle(mapButtonColor(config.SuggestionDownvote.ButtonColor));

        const row = new ActionRowBuilder().addComponents(upvoteButton, downvoteButton);

        const message = await suggestionChannel.send({ embeds: [embed], components: [row] });

        const newSuggestion = await Suggestion.create({
            uniqueId: uniqueId,
            text: suggestionText,
            authorId: interaction.user.id,
            messageId: message.id,
            channelId: suggestionChannelId,
            upvotes: 0,
            downvotes: 0
        });

        const threadName = config.SuggestionSettings.threadName.replace(/{user}/gi, interaction.user.username);
        if (threadName) {
            const thread = await message.startThread({ name: threadName, autoArchiveDuration: 60 });

            if (thread) {
                const discussButton = new ButtonBuilder()
                    .setLabel('Discuss')
                    .setStyle(ButtonStyle.Link)
                    .setURL(thread.url);

                const updatedRow = new ActionRowBuilder().addComponents(row.components).addComponents(discussButton);

                await message.edit({ components: [updatedRow] });
                newSuggestion.threadId = thread.id;
                await newSuggestion.save();
            }
        }

        const guildId = interaction.guild.id;
        const guildData = await GuildData.findOne({ guildID: guildId });
        if (guildData) {
            guildData.totalSuggestions = (guildData.totalSuggestions || 0) + 1;
            await guildData.save();
        } else {
            const newGuildData = new GuildData({
                guildID: guildId,
                cases: 0,
                totalMessages: 0,
                stars: {},
                birthday: null,
                totalSuggestions: 1,
                timesBotStarted: 0
            });
            await newGuildData.save();
        }

        await interaction.editReply({ content: lang.Suggestion.SuggestionCreated });
    } catch (error) {
        console.error('Error in creating suggestion:', error);
        await interaction.editReply({ content: lang.Suggestion.Error });
    }
}


async function upvoteSuggestion(client, interaction, uniqueId) {
    try {
        const suggestion = await Suggestion.findOne({ uniqueId: uniqueId });
        if (!suggestion) {
            return interaction.reply({
                content: lang.Suggestion.SuggestionNotFound,
                ephemeral: true
            });
        }

        if (suggestion.voters.some(voter => voter.userId === interaction.user.id)) {
            return interaction.reply({
                content: lang.Suggestion.AlreadyVoted,
                ephemeral: true
            });
        }

        suggestion.upvotes++;
        suggestion.voters.push({
            userId: interaction.user.id,
            voteType: 'upvote'
        });
        await suggestion.save();

        await updateSuggestionEmbed(client, suggestion._id);

        await interaction.reply({
            content: lang.Suggestion.Upvoted,
            ephemeral: true
        });
    } catch (error) {
        console.error('Error in upvoteSuggestion:', error);
        await interaction.reply({
            content: lang.Suggestion.Error,
            ephemeral: true
        });
    }
}


async function downvoteSuggestion(client, interaction, uniqueId) {
    try {
        const suggestion = await Suggestion.findOne({ uniqueId: uniqueId });
        if (!suggestion) {
            return interaction.reply({
                content: lang.Suggestion.SuggestionNotFound,
                ephemeral: true
            });
        }

        if (suggestion.voters.some(voter => voter.userId === interaction.user.id)) {
            return interaction.reply({
                content: lang.Suggestion.AlreadyVoted,
                ephemeral: true
            });
        }

        suggestion.downvotes++;
        suggestion.voters.push({
            userId: interaction.user.id,
            voteType: 'downvote'
        });
        await suggestion.save();

        await updateSuggestionEmbed(client, suggestion._id);

        await interaction.reply({
            content: lang.Suggestion.Downvoted,
            ephemeral: true
        });
    } catch (error) {
        console.error('Error in downvoteSuggestion:', error);
        await interaction.reply({
            content: lang.Suggestion.Error,
            ephemeral: true
        });
    }
}

async function acceptSuggestion(client, interaction, uniqueId) {
    try {
        const suggestion = await Suggestion.findOne({ uniqueId: uniqueId });
        if (!suggestion) {
            return interaction.reply({ content: lang.Suggestion.SuggestionNotFound, ephemeral: true });
        }

        if (suggestion.status !== 'Pending') {
            return interaction.reply({ content: lang.Suggestion.AlreadyProcessed, ephemeral: true });
        }

        suggestion.status = 'Accepted';

        if (suggestion.threadId) {
            const thread = await client.channels.cache.get(suggestion.threadId);
            if (thread) await thread.delete().catch(error => console.error('Error deleting thread:', error));
        }

        const user = await client.users.fetch(suggestion.authorId);
        const userIconUrl = user.displayAvatarURL();
        const embedConfig = config.SuggestionAcceptEmbed;
        const upvoteEmoji = config.SuggestionUpvote.upvoteEmoji;
        const downvoteEmoji = config.SuggestionDownvote.downvoteEmoji;
        const acceptedBy = interaction.user.username;

        const embed = new EmbedBuilder()
            .setColor(embedConfig.EmbedColor)
            .setTitle(embedConfig.EmbedTitle.replace(/{User}/gi, user.username))
            .setDescription(embedConfig.EmbedBody.join('\n')
                .replace(/{Suggestion}/gi, suggestion.text)
                .replace(/{SuggestionID}/gi, suggestion.uniqueId)
                .replace(/{UserIcon}/gi, userIconUrl)
                .replace(/{UpvoteCount}/gi, suggestion.upvotes.toString())
                .replace(/{DownvoteCount}/gi, suggestion.downvotes.toString())
                .replace(/{UpvoteEmoji}/gi, upvoteEmoji)
                .replace(/{DownvoteEmoji}/gi, downvoteEmoji)
                .replace(/{AcceptedBy}/gi, acceptedBy))
            .setFooter({
                text: embedConfig.EmbedFooter
                    .replace(/{SuggestionID}/gi, suggestion.uniqueId)
                    .replace(/{ShortTime}/gi, formatShortTime())
                    .replace(/{LongTime}/gi, formatLongTime()),
                iconURL: embedConfig.AuthorIcon ? userIconUrl : null
            });

        if (embedConfig.Thumbnail) {
            embed.setThumbnail(userIconUrl);
        }

        const acceptChannelId = embedConfig.AcceptChannelID.match(/^\d+$/) ? embedConfig.AcceptChannelID : null;

        if (acceptChannelId) {
            const acceptChannel = await client.channels.fetch(acceptChannelId);
            await acceptChannel.send({ embeds: [embed] });

            const originalChannel = client.channels.cache.get(suggestion.channelId);
            const originalMessage = await originalChannel.messages.fetch(suggestion.messageId);
            await originalMessage.delete();
        } else {
            const channel = client.channels.cache.get(suggestion.channelId);
            const message = await channel.messages.fetch(suggestion.messageId);
            await message.edit({ embeds: [embed], components: [] });
        }

        await suggestion.save();

        if (!interaction.replied && !interaction.deferred) {
            return interaction.reply({ content: lang.Suggestion.SuggestionAccepted, ephemeral: true });
        } else {
            return interaction.editReply({ content: lang.Suggestion.SuggestionAccepted });
        }
    } catch (error) {
        console.error('Error in accepting suggestion:', error);
        if (!interaction.replied && !interaction.deferred) {
            return interaction.reply({ content: lang.Suggestion.Error, ephemeral: true });
        } else {
            return interaction.editReply({ content: lang.Suggestion.Error });
        }
    }
}


async function denySuggestion(client, interaction, uniqueId) {
    try {
        const suggestion = await Suggestion.findOne({ uniqueId: uniqueId });
        if (!suggestion) {
            return interaction.reply({ content: lang.Suggestion.SuggestionNotFound, ephemeral: true });
        }

        if (suggestion.status !== 'Pending') {
            return interaction.reply({ content: lang.Suggestion.AlreadyProcessed, ephemeral: true });
        }

        suggestion.status = 'Denied';

        if (suggestion.threadId) {
            const thread = await client.channels.cache.get(suggestion.threadId);
            if (thread) await thread.delete().catch(error => console.error('Error deleting thread:', error));
        }

        const user = await client.users.fetch(suggestion.authorId);
        const userIconUrl = user.displayAvatarURL();
        const embedConfig = config.SuggestionDenyEmbed;
        const upvoteEmoji = config.SuggestionUpvote.upvoteEmoji;
        const downvoteEmoji = config.SuggestionDownvote.downvoteEmoji;
        const deniedBy = interaction.user.username;

        const embed = new EmbedBuilder()
            .setColor(embedConfig.EmbedColor)
            .setTitle(embedConfig.EmbedTitle.replace(/{User}/gi, user.username))
            .setDescription(embedConfig.EmbedBody.join('\n')
                .replace(/{Suggestion}/gi, suggestion.text)
                .replace(/{SuggestionID}/gi, suggestion.uniqueId)
                .replace(/{UserIcon}/gi, userIconUrl)
                .replace(/{UpvoteCount}/gi, suggestion.upvotes.toString())
                .replace(/{DownvoteCount}/gi, suggestion.downvotes.toString())
                .replace(/{UpvoteEmoji}/gi, upvoteEmoji)
                .replace(/{DownvoteEmoji}/gi, downvoteEmoji)
                .replace(/{DeniedBy}/gi, deniedBy))
            .setFooter({
                text: embedConfig.EmbedFooter
                    .replace(/{SuggestionID}/gi, suggestion.uniqueId)
                    .replace(/{ShortTime}/gi, formatShortTime())
                    .replace(/{LongTime}/gi, formatLongTime()),
                iconURL: embedConfig.AuthorIcon ? userIconUrl : null
            });

        if (embedConfig.Thumbnail) {
            embed.setThumbnail(userIconUrl);
        }

        const denyChannelId = embedConfig.DenyChannelID.match(/^\d+$/) ? embedConfig.DenyChannelID : null;

        if (denyChannelId) {
            const denyChannel = await client.channels.fetch(denyChannelId);
            await denyChannel.send({ embeds: [embed] });

            const originalChannel = client.channels.cache.get(suggestion.channelId);
            const originalMessage = await originalChannel.messages.fetch(suggestion.messageId);
            await originalMessage.delete();
        } else {
            const channel = client.channels.cache.get(suggestion.channelId);
            const message = await channel.messages.fetch(suggestion.messageId);
            await message.edit({ embeds: [embed], components: [] });
        }

        await suggestion.save();

        if (!interaction.replied && !interaction.deferred) {
            return interaction.reply({ content: lang.Suggestion.SuggestionDenied, ephemeral: true });
        } else {
            return interaction.editReply({ content: lang.Suggestion.SuggestionDenied });
        }
    } catch (error) {
        console.error('Error in denying suggestion:', error);
        if (!interaction.replied && !interaction.deferred) {
            return interaction.reply({ content: lang.Suggestion.Error, ephemeral: true });
        } else {
            return interaction.editReply({ content: lang.Suggestion.Error });
        }
    }
}

function replacePlaceholders(text, interaction, suggestionText, uniqueId) {
    return text.replace(/{user}/gi, interaction.user.username)
        .replace(/{suggestion}/gi, suggestionText)
        .replace(/{upvotecount}/gi, '0')
        .replace(/{downvotecount}/gi, '0')
        .replace(/{SuggestionID}/gi, uniqueId)
        .replace(/{LongTime}/gi, formatLongTime());
}

module.exports = {
    createSuggestion,
    upvoteSuggestion,
    downvoteSuggestion,
    updateSuggestionEmbed,
    acceptSuggestion,
    denySuggestion
};