const Suggestion = require('../../models/Suggestion');

const suggestionUtils = {
    /**
     * Retrieves a suggestion from the database by its ID.
     * @param {String} suggestionId - The ID of the suggestion.
     * @returns {Promise<Object>} The suggestion document.
     */
    getSuggestionById: async function (suggestionId) {
        try {
            const suggestion = await Suggestion.findById(suggestionId);
            return suggestion;
        } catch (error) {
            console.error('Error fetching suggestion:', error);
            throw error;
        }
    },

    /**
     * Checks if a user has already voted on a suggestion.
     * @param {Object} suggestion - The suggestion document.
     * @param {String} userId - The ID of the user.
     * @param {String} voteType - The type of vote ('upvote' or 'downvote').
     * @returns {Boolean} True if the user has voted, false otherwise.
     */
    hasUserVoted: function (suggestion, userId, voteType) {
        return suggestion.voters.some(voter => voter.userId === userId && voter.voteType === voteType);
    },

    /**
     * Adds a vote to a suggestion.
     * @param {Object} suggestion - The suggestion document.
     * @param {String} userId - The ID of the user who is voting.
     * @param {String} voteType - The type of vote ('upvote' or 'downvote').
     */
    addVote: async function (suggestion, userId, voteType) {
        if (this.hasUserVoted(suggestion, userId, voteType)) {
            throw new Error('User has already voted');
        }

        suggestion.voters.push({ userId, voteType });
        if (voteType === 'upvote') {
            suggestion.upvotes++;
        } else if (voteType === 'downvote') {
            suggestion.downvotes++;
        }
        await suggestion.save();
    }
};

module.exports = suggestionUtils;