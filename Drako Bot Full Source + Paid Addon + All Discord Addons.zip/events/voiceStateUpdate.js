const { ChannelType, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const yaml = require('js-yaml');
const moment = require('moment-timezone');
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'));
const TempVoiceChannel = require('../models/TempVoiceChannel');
const TriggerChannel = require('../models/TriggerChannel');
const TempVoiceBans = require('../models/TempVoiceBans');
const client = require('../index')


client.on('voiceStateUpdate', async (oldState, newState) => {
    try {
        if (newState.channelId) {
            const trigger = await TriggerChannel.findOne({ triggerChannelId: newState.channelId });
            if (trigger) {
                await handleUserJoiningTriggerChannel(newState, trigger);
            }
        }

        if (oldState.channelId && oldState.channelId !== newState.channelId) {
            await handleUserLeavingChannel(oldState.guild, oldState.channelId);
        }
    } catch (error) {
        console.error('Error in voiceStateUpdate event:', error);
    }
});


function getVoiceStateConfig(oldState, newState) {
    if (newState.channelId === null && config.VoiceChannelLeave && config.VoiceChannelLeave.Enabled) {
        return config.VoiceChannelLeave;
    } else if (oldState.channelId === null && config.VoiceChannelJoin && config.VoiceChannelJoin.Enabled) {
        return config.VoiceChannelJoin;
    } else if (oldState.channelId !== newState.channelId && config.VoiceChannelSwitch && config.VoiceChannelSwitch.Enabled) {
        return config.VoiceChannelSwitch;
    } else if (oldState.streaming !== newState.streaming) {
        if (newState.streaming && config.VoiceChannelStreamStart && config.VoiceChannelStreamStart.Enabled) {
            return config.VoiceChannelStreamStart;
        } else if (!newState.streaming && config.VoiceChannelStreamStop && config.VoiceChannelStreamStop.Enabled) {
            return config.VoiceChannelStreamStop;
        }
    }
    return null;
}


function replacePlaceholders(text, oldState, newState) {
    const currentTime = moment().tz(config.Timezone);
    const shortTime = currentTime.format("HH:mm");
    const longTime = currentTime.format('MMMM Do YYYY');
    let oldChannelName = oldState.channel ? oldState.channel.name : "None";
    let newChannelName = newState.channel ? newState.channel.name : "None";

    let channelName = newState.channelId ? newChannelName : oldChannelName;

    return text.replace(/{user}/g, `<@${newState.member.id}>`)
        .replace(/{oldChannel}/g, oldChannelName)
        .replace(/{newChannel}/g, newChannelName)
        .replace(/{channel}/g, channelName)
        .replace(/{shorttime}/g, shortTime)
        .replace(/{longtime}/g, longTime);
}


async function sendVoiceStateEmbed(oldState, newState, voiceConfig) {
    if (!voiceConfig || !voiceConfig.Enabled) return;

    const embedConfig = voiceConfig.StartEmbed;
    const embed = new EmbedBuilder()
        .setColor(embedConfig.Color)
        .setTitle(replacePlaceholders(embedConfig.Title, oldState, newState))
        .setDescription(embedConfig.Description.map(line => replacePlaceholders(line, oldState, newState)).join("\n"))
        .setFooter({ text: replacePlaceholders(embedConfig.Footer, oldState, newState) });

    if (voiceConfig.Thumbnail) {
        embed.setThumbnail(newState.member.user.displayAvatarURL());
    }

    const voiceLogChannel = newState.guild.channels.cache.get(voiceConfig.LogsChannelID);
    if (voiceLogChannel) {
        try {
            await voiceLogChannel.send({ embeds: [embed] });
        } catch (error) {
        }
    }
}


async function handleUserJoiningTriggerChannel(newState, trigger) {
    if (!trigger || !trigger.namePattern) {
        return;
    }

    let tempChannel;
    try {
        const tempChannelName = trigger.namePattern.replace('{user}', newState.member.user.username);
        tempChannel = await newState.guild.channels.create({
            name: tempChannelName,
            type: ChannelType.GuildVoice,
            parent: trigger.categoryId ? newState.guild.channels.cache.get(trigger.categoryId) : null
        });


        const permissionOverwrites = [
            {
                id: newState.guild.roles.everyone.id,
                allow: [PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak]
            },
            {
                id: newState.member.user.id,
                allow: [PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak]
            }
        ];

        const banList = await TempVoiceBans.findOne({ discordId: newState.member.user.id });
        if (banList && banList.bannedUsers.length > 0) {
            banList.bannedUsers.forEach(bannedUserId => {
                permissionOverwrites.push({
                    id: bannedUserId,
                    deny: [PermissionsBitField.Flags.Connect]
                });
            });
        }


        await tempChannel.permissionOverwrites.set(permissionOverwrites);


        const member = await newState.guild.members.fetch(newState.member.id);
        if (member.voice.channelId === newState.channelId) {
            await member.voice.setChannel(tempChannel);

            const tempVoiceChannel = new TempVoiceChannel({
                guildId: newState.guild.id,
                triggerChannelId: newState.channelId,
                tempChannelId: tempChannel.id,
                creatorId: newState.member.user.id,
                isActive: true
            });
            await tempVoiceChannel.save();
        } else {
            await tempChannel.delete();
        }
    } catch (error) {
        if (tempChannel) {
            try {
                await tempChannel.delete();
            } catch (deleteError) {
            }
        }
    }
};


async function handleUserLeavingChannel(guild, channelId) {
    const tempVoiceChannelRecord = await TempVoiceChannel.findOne({ tempChannelId: channelId });
    if (!tempVoiceChannelRecord) return;

    const tempChannel = guild.channels.cache.get(channelId);
    if (tempChannel && tempChannel.members.size === 0) {
        try {
            await tempChannel.delete();
            await TempVoiceChannel.deleteOne({ tempChannelId: channelId });
        } catch (error) {
        }
    }
}


module.exports = async (client, oldState, newState) => {
    try {
        if (!oldState.channel && !newState.channel) {
            return;
        }

        const voiceStateConfig = getVoiceStateConfig(oldState, newState);
        if (!voiceStateConfig) {
            return;
        }

        await sendVoiceStateEmbed(oldState, newState, voiceStateConfig);
        if (oldState.channelId && oldState.channelId !== newState.channelId) {
            await handleUserLeavingChannel(oldState.guild, oldState.channelId);
        }
    } catch (error) {
        console.error('Error in voice state update event:', error);
    }
};