const fs = require('fs');
const yaml = require("js-yaml");
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'));
const fetch = require('node-fetch');
const lang = yaml.load(fs.readFileSync('./lang.yml', 'utf8'));

module.exports = async (client, reaction, user) => {
    if (!reaction || !user || user.bot || !reaction.message || !reaction.message.channel.guild) return;

    let guild = client.guilds.cache.get(config.GuildID);
    reaction.message.fetch();

    config.ReactionRoles.forEach(reactionRole => {
        let regex = reactionRole.emojiName.replace(/[0-9]/g, '').replace(/[:]/g, '').replace(/[<]/g, '').replace(/[>]/g, '')
        let emoji = regex || reactionRole.emojiName;
        if (reaction.message.id === reactionRole.messageID && reaction.emoji.name === emoji) {
            let role = reaction.message.channel.guild.roles.cache.get(reactionRole.roleID);
            if (!role) {
                console.log(`[REACTION ROLES] Role (${reactionRole.roleID}) not found in ReactionRoles.roleID`);
                return;
            }
            const member = guild.members.cache.get(user.id);
            if (member && !member.roles.cache.has(role.id)) {
                member.roles.add(role).catch(console.error);
            } else if (member) {
                member.roles.remove(role).catch(console.error);
            }
        }
    });
}