const { Collection, Client, Discord, Intents, EmbedBuilder, PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle} = require("discord.js");
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('./lang.yml', 'utf8'))
const moment = require('moment-timezone');
const colors = require('ansi-colors');
const handleXP = require('./Levels/handleXP');
const handleMessageCount = require('./Levels/handleMessageCount');
const UserData = require('../models/UserData');
const utils = require('../utils');
const GuildData = require('../models/guildDataSchema');
const AFK = require('../models/afkSchema');  
const ms = require("parse-duration");
const { error } = require("console");

let spamData = new Map();

function replaceAFKPlaceholders(template, placeholders = {}) {
    if (!template) {
        return '\u200b'; 
    }

    return Object.keys(placeholders).reduce((acc, key) => {
        const regex = new RegExp(`{${key}}`, 'gi');
        return acc.replace(regex, placeholders[key] || '');
    }, template);
}

function parseCustomDuration(durationStr) {
    const timeUnits = {
        s: 1000,      
        m: 60 * 1000,    
        h: 60 * 60 * 1000
    };
    return durationStr.split(' ').reduce((totalMilliseconds, part) => {
        const unit = part.slice(-1);
        const value = parseInt(part.slice(0, -1), 10);
        return totalMilliseconds + (value * (timeUnits[unit] || 0));
    }, 0);
}

async function sendDirectMessage(user, template, data) {
    let messageContent = template
        .replace(/{user}/g, user.username)
        .replace(/{guildname}/g, data.guildName)
        .replace(/{message}/g, data.messageContent)
        .replace(/{time}/g, data.timeoutDuration);
    try {
        await user.send(messageContent);
    } catch (error) {
        console.log(`Could not send DM to ${user.username}: ${error}`);
    }
}

function hasPermissionOrRole(member, perms, roles) {
    return perms.some(perm => member.permissions.has(perm)) || roles.some(role => member.roles.cache.has(role));
}

function sendLogMessage(guild, channelId, embed) {
    const logChannel = guild.channels.cache.get(channelId);
    if (logChannel) {
        logChannel.send({ embeds: [embed] });
    } else {
    }
}


function createLogEmbed(author, color, title, description, fields, footerText) {
    return new EmbedBuilder()
        .setAuthor({ name: author })
        .setColor(color)
        .setTitle(title)
        .setDescription(description)
        .addFields(fields)
        .setTimestamp()
        .setFooter({ text: footerText });
}


function humanReadableDuration(milliseconds) {
    if (milliseconds < 1000) return "Less than a second";

    let totalSeconds = Math.floor(milliseconds / 1000);
    let totalMinutes = Math.floor(totalSeconds / 60);
    let totalHours = Math.floor(totalMinutes / 60);
    let days = Math.floor(totalHours / 24);
    let weeks = Math.floor(days / 7);
    let months = Math.floor(days / 30);
    let years = Math.floor(days / 365);

    totalSeconds %= 60;
    totalMinutes %= 60;
    totalHours %= 24;
    days %= 7;
    weeks %= 4;
    months %= 12;

    let duration = '';
    if (years > 0) duration += `${years} year${years > 1 ? 's' : ''}, `;
    if (months > 0) duration += `${months} month${months > 1 ? 's' : ''}, `;
    if (weeks > 0) duration += `${weeks} week${weeks > 1 ? 's' : ''}, `;
    if (days > 0) duration += `${days} day${days > 1 ? 's' : ''}, `;
    if (totalHours > 0) duration += `${totalHours} hour${totalHours > 1 ? 's' : ''}, `;
    if (totalMinutes > 0) duration += `${totalMinutes} minute${totalMinutes > 1 ? 's' : ''}, `;
    if (totalSeconds > 0) duration += `${totalSeconds} second${totalSeconds > 1 ? 's' : ''}`;

    return duration.replace(/,\s*$/, "");
}

function formatDuration(durationMs) {
    const seconds = Math.floor((durationMs / 1000) % 60);
    const minutes = Math.floor((durationMs / (1000 * 60)) % 60);
    const hours = Math.floor((durationMs / (1000 * 60 * 60)) % 24);
    const days = Math.floor(durationMs / (1000 * 60 * 60 * 24));

    const parts = [];
    if (days > 0) parts.push(days + ' day' + (days === 1 ? '' : 's'));
    if (hours > 0) parts.push(hours + ' hour' + (hours === 1 ? '' : 's'));
    if (minutes > 0) parts.push(minutes + ' minute' + (minutes === 1 ? '' : 's'));
    if (seconds > 0) parts.push(seconds + ' second' + (seconds === 1 ? '' : 's'));

    return parts.join(', ');
}

module.exports = async (client, message) => {
    if (!message.guild || !message.member || message.author.bot) return;

    try {
        const messageContent = message.content; 
        const timeSent = new Date(); 

       
        await UserData.findOneAndUpdate(
            { userId: message.author.id, guildId: message.guild.id }, 
            {
                $push: {
                    messages: { content: messageContent, timeSent: timeSent } 
                },
                $inc: { totalMessages: 1 } 
            },
            { new: true, upsert: true } 
        );
    } catch (error) {
        console.error('Error saving message to database:', error);
    }

    await handleMessageCount(message);
    await handleXP(message);
    await checkAutoReact(message);
    await checkPingAfkUser(message);

    let dmSent = false;

    dmSent = await checkBlacklistWords(message, dmSent);
    dmSent = await checkAntiInviteLinks(message, dmSent);
    dmSent = await checkAntiMassMention(message, dmSent);
    dmSent = await checkAntiSpam(message, dmSent);

    GuildData.findOneAndUpdate(
        { guildID: message.guild.id },
        { $inc: { totalMessages: 1 } },
        { new: true, upsert: true, setDefaultsOnInsert: true }
    ).catch(console.error);

    processCustomCommands(client, message);
    processAutoResponses(message);
    handleVerificationSettings(message);
};


async function checkPingAfkUser(message) {
    if (message.author.bot || !message.content) {
        return;
    }

    const authorAfkStatus = await AFK.findOne({ userId: message.author.id, afk: true });
    if (authorAfkStatus && authorAfkStatus.notifyMessageId && authorAfkStatus.notifyChannelId) {
        try {
            const channel = await message.client.channels.fetch(authorAfkStatus.notifyChannelId);
            const notifyMessage = await channel.messages.fetch(authorAfkStatus.notifyMessageId);
            await notifyMessage.delete();
        } catch (error) {
        }

    await AFK.updateOne({ userId: message.author.id }, { $set: { afk: false, notifyMessageId: "", notifyChannelId: "" } }); 
    try {
        const user = message.author;
        const placeholders = {
            user:  message?.author.username || "user",
            username: user?.displayName || "user",
            reason: authorAfkStatus.afkMessage,
            backTime: `<t:${Math.floor(authorAfkStatus.backTime / 1000)}:R>`,
        };

        if(config.AFK.SendNoLongerAfkMessage) {
            const noLongerAfkMessage = removeTags(replaceAFKPlaceholders(config.AFK.NoLongerAfkMessage, placeholders));
            message.channel.send(noLongerAfkMessage);
        }
    } catch(error) {
      console.log(error)
    }
     
    }

    if (authorAfkStatus && authorAfkStatus.oldDisplayName != null) {
        const member = await message.guild.members.fetch(message.author.id);
        try {
            await member.setNickname(authorAfkStatus.oldDisplayName);
        } catch (error) {
        }
    }

    if (config.AFK.EnableAfkRole) {
        const afkRole = message.guild.roles.cache.find(role => role.name === config.AFK.AfkRoleName);
        if (afkRole) {
            const member = await message.guild.members.fetch(message.author.id);
            try {
                await member.roles.remove(afkRole);
            } catch (error) {
            }
        }
    }

    const mentionedUsers = message.mentions.users;


    for (const [userId, user] of mentionedUsers) {
        const afkStatus = await AFK.findOne({ userId: userId, afk: true });
        if (afkStatus) {
            const noBackTime = afkStatus.noBackTime;
 
            const afkDurationMs = afkStatus.backTime - Date.now();
            const afkDuration = formatDuration(afkDurationMs);
            const placeholders = {
                user: user.username,
                username: user.displayName,
                reason: afkStatus.afkMessage,
                backTime: noBackTime ? config.AFK.NoBackTime : `<t:${Math.floor(afkStatus.backTime / 1000)}:R>`,
            };

            const replyEmbed = new EmbedBuilder();

            if (config.AFK.ReplyEmbed.EmbedColor) {
                replyEmbed.setColor(config.AFK.ReplyEmbed.EmbedColor);
            }
  
            if (config.AFK.ReplyEmbed.Description) {
                let descriptionLines = config.AFK.ReplyEmbed.Description.map(line =>
                    replaceAFKPlaceholders(line, placeholders)
                );
                if (noBackTime) {
                    descriptionLines.pop(); 
                }
 
                replyEmbed.setDescription(descriptionLines.join('\n'));
            }
        
 
            if (config.AFK.ReplyEmbed.Title) {
                replyEmbed.setTitle(replaceAFKPlaceholders(config.AFK.ReplyEmbed.Title, placeholders));
            }

            if (config.AFK.ReplyEmbed.EmbedImage) {
                replyEmbed.setImage(config.AFK.ReplyEmbed.EmbedImage);
            }

            if (config.AFK.ReplyEmbed.EmbedThumbnail) {
                replyEmbed.setThumbnail(config.AFK.ReplyEmbed.EmbedThumbnail);
            }


            if (config.AFK.ReplyToPinger) {
                if (config.AFK.UseReplyEmbed) {
                    const replyPingerEmbed = new EmbedBuilder()
                        .setColor(config.AFK.ReplyEmbed.EmbedColor);
                        
                        if (config.AFK.ReplyEmbed.Description) {
                            let descriptionLines = config.AFK.ReplyEmbed.Description.map(line =>
                                replaceAFKPlaceholders(line, placeholders)
                            );
                
                            if (noBackTime) {
                                descriptionLines.pop();
                            }
                
                            replyPingerEmbed.setDescription(descriptionLines.join('\n'));
                        }

                    if (config.AFK.ReplyEmbed.Title) replyPingerEmbed.setTitle(config.AFK.ReplyEmbed.Title.replace(/\{(.*?)\}/g, (_, key) => placeholders[key] || key));
                    if (config.AFK.ReplyEmbed.EmbedImage) replyPingerEmbed.setImage(config.AFK.ReplyEmbed.EmbedImage);
                    if (config.AFK.ReplyEmbed.EmbedThumbnail) replyPingerEmbed.setThumbnail(config.AFK.ReplyEmbed.EmbedThumbnail);
                        message.channel.send({ embeds: [replyPingerEmbed] });
                     
                } else {
                   
                    const replyMessage = removeTags(config.AFK.ReplyMessage.replace(/\{(.*?)\}/g, (_, key) => placeholders[key] || key));
                    message.channel.send(replyMessage);
                }
            }
           
        } else {
        }
    }
}


function convertSimplePatternToRegex(simplePattern) {
    let regexPattern = simplePattern
        .replace(/\./g, '\\.')
        .replace(/\*/g, '.*');
    return new RegExp(regexPattern, 'i');
}


async function checkBlacklistWords(message) {
    if (!config.BlacklistWords.Enabled) return;

    if (hasPermissionOrRole(message.member, config.BlacklistWords.BypassPerms, config.BlacklistWords.BypassRoles)) {
        return;
    }

    const channelId = message.channel.id;
    const categoryId = message.channel.parentId;

    const isChannelWhitelisted = config.BlacklistWords.WhitelistChannels.includes(channelId);
    const isCategoryWhitelisted = config.BlacklistWords.WhitelistCategories.includes(categoryId);
    if (isChannelWhitelisted || isCategoryWhitelisted) return;

    const whitelistRegex = config.BlacklistWords.WhitelistWords.map(word => convertSimplePatternToRegex(word));
    const isWhitelisted = whitelistRegex.some(regex => regex.test(message.content));
    if (isWhitelisted) return;

    let triggeredWord = null;

    const blacklistRegex = config.BlacklistWords.Patterns.map(pattern => convertSimplePatternToRegex(pattern));
    const isBlacklisted = blacklistRegex.some(regex => {
        const match = message.content.match(regex);
        if (match) {
            triggeredWord = match[0];
            return true;
        }
        return false;
    });

    if (isBlacklisted && triggeredWord) {
        try {
            await message.delete();
        } catch (error) {
            console.error("Error deleting message:", error);
        }

        const filterWordsMsg = config.BlacklistWords.Message.replace(/{user}/g, `<@${message.author.id}>`);
        await message.channel.send(filterWordsMsg).then(msg => setTimeout(() => msg.delete(), 3000));

        if (config.BlacklistWords.DM.Enabled) {
            const dmEmbed = new EmbedBuilder()
                .setColor(config.BlacklistWords.DM.Embed.Color || "#FF0000")
                .setTitle(`Blacklisted Word Detected: ${triggeredWord}`)
                .setDescription(`The message containing the word "${triggeredWord}" was deleted.`)
                .setFooter({ text: "Detected at " + moment().format("HH:mm") });

            try {
                await message.author.send({ embeds: [dmEmbed] });
            } catch (error) {
                console.error("Error sending DM:", error);
            }
        }
    }
}


async function checkAutoReact(message) {
    if (!config.AutoReact || !config.AutoReact.Enabled) return;

    config.AutoReact.Reactions.forEach(reaction => {
        if (message.content.toLowerCase().includes(reaction.keyword.toLowerCase())) {
            if (isEligibleForReaction(message, reaction)) {
                message.react(reaction.emoji).catch(console.error);
            }
        }
    });
}


function isEligibleForReaction(message, reaction) {
    const memberRoles = message.member.roles.cache;
    const channelId = message.channel.id;
    const validRoleIds = reaction.whitelistRoles.filter(roleId => !isNaN(roleId));
    const isRoleEligible = validRoleIds.length === 0 ||
        memberRoles.some(role => validRoleIds.includes(role.id));
    const validChannelIds = reaction.whitelistChannels.filter(channelId => !isNaN(channelId));
    const isChannelEligible = validChannelIds.length === 0 ||
        validChannelIds.includes(channelId);
    return isRoleEligible && isChannelEligible;
}


async function checkAntiInviteLinks(message) {
    if (!config.AntiInviteLinks || !config.AntiInviteLinks.Enabled) {
        return;
    }

    const channelId = message.channel.id;
    const categoryID = message.channel.parentId;

    const isChannelWhitelisted = config.AntiInviteLinks.WhitelistChannel.includes(channelId);
    const isCategoryWhitelisted = config.AntiInviteLinks.WhitelistCategory.includes(categoryID);
    if (isChannelWhitelisted || isCategoryWhitelisted) return;

    const inviteBypass = hasPermissionOrRole(message.member, config.AntiInviteLinks.BypassPerms, config.AntiInviteLinks.BypassRoles);
    if (inviteBypass) return;

    const adURL = /(https?:\/\/)?(www\.)?(discord\.(gg|io|me|li)|discordapp\.com\/invite)\/.+[a-z]/;
    if (adURL.test(message.content)) {
        try {
            await message.delete();
        } catch (error) {
            if (error.code === 10008) {
             //   console.error("Tried to delete a message that doesn't exist.");
            } else {
             //   console.error("An error occurred while trying to delete the message:", error);
            }
        }

        const warningMessage = await message.channel.send(config.AntiInviteLinks.Message.replace(/{user}/g, `<@${message.author.id}>`));
        setTimeout(() => warningMessage.delete().catch(console.error), 3000);

        if (config.AntiInviteLinks.TimeoutUser) {
            const timeInMs = parseCustomDuration(config.AntiInviteLinks.TimeoutTime);
            try {
                await message.member.timeout(timeInMs, "Posting Invite Link (Auto Moderation)");
            } catch (error) {
                console.error("An error occurred while trying to timeout the user:", error);
            }
        }

        if (config.AntiInviteLinks.DM && config.AntiInviteLinks.DM.Enabled) {
            const foundInviteLink = message.content.match(adURL)[0];
            const dmEmbed = new EmbedBuilder()
                .setColor(config.AntiInviteLinks.DM.Color)
                .setTitle(replacePlaceholders(config.AntiInviteLinks.DM.Embed.Title, message, null, foundInviteLink))
                .setDescription(replacePlaceholders(config.AntiInviteLinks.DM.Embed.Description.join('\n'), message, null, foundInviteLink))
                .setFooter({ text: replacePlaceholders(config.AntiInviteLinks.DM.Embed.Footer, message, null, foundInviteLink) });

            if (config.AntiInviteLinks.DM.Embed.Thumbnail) {
                dmEmbed.setThumbnail(message.author.displayAvatarURL());
            }

            try {
                await message.author.send({ embeds: [dmEmbed] });
            } catch (error) {
                console.error("Failed to send DM:", error);
            }
        }
    }
}

async function checkAntiMassMention(message) {
    if (!config.AntiMassMention.Enabled) return;

    const mentionBypass = hasPermissionOrRole(message.member, config.AntiMassMention.BypassPerms, config.AntiMassMention.BypassRoles);
    if (mentionBypass) return;

    if (message.mentions.users.size > config.AntiMassMention.Amount) {
        message.delete();
        message.channel.send(config.AntiMassMention.Message.replace(/{user}/g, `${message.author}`))
            .then(msg => setTimeout(() => msg.delete(), 3000));

        if (config.AntiMassMention.TimeoutUser) {
            const timeInMs = parseCustomDuration(config.AntiMassMention.TimeoutTime);
            message.member.timeout(timeInMs, "Mass Mention (Auto Moderation)").catch(console.error);
            UserData.updateOne(
                { userId: message.author.id, guildId: message.guild.id },
                { $inc: { timeouts: 1 } }
            ).catch(console.error);

            const logEmbed = createLogEmbed(
                'Auto Moderation',
                'Red',
                'Mass Mention Detected',
                `**User:** <@${message.author.id}> \n**Action:** Timeout`,
                [
                    { name: 'Reason', value: 'Mass Mention', inline: true },
                    { name: 'Duration', value: humanReadableDuration(timeInMs), inline: true }
                ],
                `User ID: ${message.author.id}`
            );

            sendLogMessage(message.guild, config.AntiMassMention.LogsChannelID, logEmbed);

            if (config.AntiMassMention.SendDM) {
                const dmData = {
                    guildName: message.guild.name,
                    messageContent: message.content,
                    timeoutDuration: humanReadableDuration(timeInMs)
                };
                sendDirectMessage(message.author, config.AntiMassMention.DirectMessage, dmData);
            }
        }
    }
}
 
async function checkAntiSpam(message) {
    if (!config.AntiSpam.Enabled) return;

    const spamBypass = hasPermissionOrRole(message.member, config.AntiSpam.BypassPerms, config.AntiSpam.BypassRoles);
    if (spamBypass) return;

    if (spamData.has(message.author.id)) {
        const userData = spamData.get(message.author.id);
        userData.msgCount++;
        spamData.set(message.author.id, userData);

        if (userData.msgCount === config.AntiSpam.MsgLimit) {
            const timeInMs = parseCustomDuration(config.AntiSpam.TimeoutTime);
            try {
                await message.member.timeout(timeInMs, "Spamming (Auto Moderation)");
                UserData.updateOne(
                    { userId: message.author.id, guildId: message.guild.id },
                    { $inc: { timeouts: 1 } }
                ).catch(console.error);

                const logEmbed = createLogEmbed(
                    'Auto Moderation',
                    'Red',
                    'Spam Detected',
                    `**User:** <@${message.author.id}> \n**Action:** Timeout`,
                    [
                        { name: 'Reason', value: 'Spamming Messages', inline: true },
                        { name: 'Duration', value: humanReadableDuration(timeInMs), inline: true }
                    ],
                    `User ID: ${message.author.id}`
                );

                sendLogMessage(message.guild, config.AntiSpam.LogsChannelID, logEmbed);

                if (config.AntiSpam.SendDM) {
                    const dmData = {
                        guildName: message.guild.name,
                        messageContent: message.content,
                        timeoutDuration: humanReadableDuration(timeInMs)
                    };
                    sendDirectMessage(message.author, config.AntiSpam.DirectMessage, dmData);
                }
            } catch (error) {
            }
        }
        if (userData.msgCount >= config.AntiSpam.MsgLimit) {
            message.channel.bulkDelete(config.AntiSpam.MsgLimit).catch(console.error);
            spamData.delete(message.author.id);
        }
    } else {
        spamData.set(message.author.id, { msgCount: 1 });
        setTimeout(() => {
            if (spamData.has(message.author.id)) {
                spamData.delete(message.author.id);
            }
        }, parseCustomDuration(config.AntiSpam.TimeLimit));
    }
}
 
function isValidHttpUrl(string) {
    let url;
    
    try {
        url = new URL(string);
    } catch (_) {
        return false;  
    }

    return url.protocol === "http:" || url.protocol === "https:";
}

function removeTags(text) {
    text = text.replace(/@everyone/gi, "everyone").replace(/@here/gi, "here");
    text = text.replace(/<@&\d+>/g, "(role mention removed)");
    text = text.replace(/@(?!everyone|here)(\w+)/gi, "$1");
    return text;
}


function replaceCustomCommandPlaceholders(template, placeholders = {}) {
    if (!template) {
        return '\u200b'; 
    }

    return Object.keys(placeholders).reduce((acc, key) => {
        const regex = new RegExp(`{${key}}`, 'gi');
        return acc.replace(regex, placeholders[key] || '');
    }, template);
}


async function processCustomCommands(client,message) {

    try {
        if (!config.CommandsEnabled || message.author.bot || !message.content.startsWith(config.CommandsPrefix)) {
            return;
        }
    
        const args = message.content.slice(config.CommandsPrefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();
        const command = config.CustomCommands[commandName];
        if (!command) return;
    
        const memberRoles = message.member.roles.cache.map(role => role.id);
        const isWhitelisted = command.roles.whitelist.length === 0 || command.roles.whitelist.some(roleId => memberRoles.includes(roleId));
        const isBlacklisted = command.roles.blacklist.some(roleId => memberRoles.includes(roleId));
        if (!isWhitelisted || isBlacklisted) return;
        const currentTime = moment().tz(config.Timezone);
    
        const placeholders = {
            guildName: message.guild.name,  
            guildId: message.guild.id,  
            userName: message.author.username,  
            userId: message.author.id,  
            userMention: message.author.toString(),  
            channelName: message.channel.name,  
            channelId: message.channel.id,  
            channelMention: message.channel.toString(),  
            commandName: commandName,  
            longtime: currentTime.format('MMMM Do YYYY'),
            shorttime: currentTime.format("HH:mm"),
            memberCount: message.guild.memberCount
        };
    
     
        let responseOptions = {};
        if (command.type === "EMBED") {
            const embed = new EmbedBuilder()
                .setColor(command.Embed.embedColor)
                .setTitle(replaceCustomCommandPlaceholders(command.Embed.embedTitle , placeholders))
                .setDescription( replaceCustomCommandPlaceholders(command.Embed.embedDescription.join("\n"),placeholders));
    
                if (command.Embed.embedFooter) {
                    if (command.Embed.footerIconUrl) {
                        embed.setFooter({
                            text: command.Embed.embedFooter,
                            iconURL: command.Embed.footerIconUrl.replace("{userAvatar}", message.author.displayAvatarURL())
                        });
                    } else {
                        embed.setFooter({ text: command.Embed.embedFooter });
                    }
                }
      
            if (isValidHttpUrl(command.Embed.thumbnailUrl)) {
                embed.setThumbnail(command.Embed.thumbnailUrl);
            }  
            if (isValidHttpUrl(command.Embed.thumbnailUrl)) {
                embed.setImage(command.Embed.imageUrl);
            }  
            if (isValidHttpUrl(command.Embed.authorIconUrl)) {
                embed.setAuthor({ name: message.author.username, iconURL: command.Embed.authorIconUrl });
            }  
     
            if (command.Embed.embedFields) {
                command.Embed.embedFields.forEach(field => {
                    const fieldName = replaceCustomCommandPlaceholders(field.name, placeholders);
                    const fieldValue = replaceCustomCommandPlaceholders(field.value, placeholders);
                    embed.addFields({ name: fieldName, value: fieldValue, inline: field.inline ?? false });
                });
            }
    
            responseOptions.embeds = [embed];
        } else if (command.type === "TEXT") {
            responseOptions.content = command.text;
        }
    
        try {
            if (command.options.replyToUser) {
                await message.reply(responseOptions);
            } else {
                await message.channel.send(responseOptions);
            }
    
            if (command.options.deleteTriggerMessage) {
                await message.delete();
            }
        } catch (error) {
            console.error('Error sending message: ', error);
        }
    } catch(error) {
          console.error('Error sending message: ', error);

    }
  
}


function processAutoResponses(message) {
    if (!config.AutoResponse.Enabled) {
        return;
    }

    for (const trigger in config.AutoResponse.Responses) {

        if (message.content.toLowerCase().includes(trigger.toLowerCase())) {
            const autoResp = config.AutoResponse.Responses[trigger];

            autoResp.WhitelistRoles = autoResp.WhitelistRoles.filter(role => !isNaN(role));
            autoResp.BlacklistRoles = autoResp.BlacklistRoles.filter(role => !isNaN(role));
            autoResp.WhitelistChannels = autoResp.WhitelistChannels.filter(channel => !isNaN(channel));
            autoResp.BlacklistChannels = autoResp.BlacklistChannels.filter(channel => !isNaN(channel));

            const hasWhitelistRole = autoResp.WhitelistRoles.length === 0 || autoResp.WhitelistRoles.some(role => message.member.roles.cache.has(role));
            const hasBlacklistRole = autoResp.BlacklistRoles.some(role => message.member.roles.cache.has(role));
            const inWhitelistChannel = autoResp.WhitelistChannels.length === 0 || autoResp.WhitelistChannels.includes(message.channel.id);
            const inBlacklistChannel = autoResp.BlacklistChannels.includes(message.channel.id);

            if (!hasWhitelistRole || hasBlacklistRole || !inWhitelistChannel || inBlacklistChannel) {
                return;
            }

            try {
                if (config.AutoResponse.MessageType === "EMBED") {
                    const embedConfig = autoResp.Embed;
                    const embed = new EmbedBuilder()
                        .setColor(embedConfig.Color)
                        .setTitle(replacePlaceholders(embedConfig.Title, message))
                        .setDescription(replacePlaceholders(embedConfig.Description.join('\n'), message))
                        .setFooter({ text: replacePlaceholders(embedConfig.Footer, message) });

                    if (embedConfig.Thumbnail) {
                        embed.setThumbnail(message.author.displayAvatarURL());
                    }

                    message.reply({ embeds: [embed] });
                } else {
                    const textResponse = replacePlaceholders(autoResp.Text, message);
                    message.reply(textResponse);
                }
            } catch (error) {
                console.error("processAutoResponses: Error sending response -", error);
            }
            break;
        }
    }
}


function replacePlaceholders(text, message, blacklistedWord = null, antiInviteLink = null) {
    if (!text || !message) return '';

    const currentTime = moment().tz(config.Timezone);
    return text
        .replace(/{user}/g, message.author ? `<@${message.author.id}>` : 'Unknown User')
        .replace(/{userName}/g, message.author ? message.author.username : 'Unknown Username')
        .replace(/{userTag}/g, message.author ? message.author.tag : 'Unknown UserTag')
        .replace(/{userId}/g, message.author ? message.author.id : 'Unknown UserID')
        .replace(/{guildName}/g, message.guild ? message.guild.name : 'Unknown Guild')
        .replace(/{channelName}/g, message.channel ? message.channel.name : 'Unknown Channel')
        .replace(/{channelId}/g, message.channel ? message.channel.id : 'Unknown ChannelID')
        .replace(/{blacklistedword}/g, blacklistedWord || 'None')
        .replace(/{antiinvitelink}/g, antiInviteLink || 'No Link Detected')
        .replace(/{shorttime}/g, currentTime.format("HH:mm"))
        .replace(/{longtime}/g, currentTime.format('MMMM Do YYYY'));
}
 
function handleVerificationSettings(message) {
    try {
        if (config.VerificationSettings.Enabled && config.VerificationSettings.DeleteAllMessages && message.channel.id === config.VerificationSettings.ChannelID) {
            message.delete().catch((error) => {
                if (error.code !== 10008) {
                 //   console.error("Error deleting message:", error);
                }
            });
        }
    } catch (error) {
       // console.error("An unexpected error occurred:", error);
    }
}
