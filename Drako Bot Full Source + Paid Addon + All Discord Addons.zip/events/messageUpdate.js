const { EmbedBuilder } = require("discord.js");
const fs = require('fs');
const yaml = require("js-yaml");
const moment = require('moment-timezone');
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'));

module.exports = async (client, oldMessage, newMessage) => {
    if (!newMessage.guild || !newMessage.author || newMessage.author.bot || !newMessage.content) return;
    if (oldMessage.content === newMessage.content) return;
    if (config.MessageUpdateLogs.Enabled) {
        const editLogChannel = newMessage.guild.channels.cache.get(config.MessageUpdateLogs.LogsChannelID);
        if (!editLogChannel) return;

        const currentTime = moment().tz(config.Timezone);

        let embedData = config.MessageUpdateLogs.Embed;
        let embed = new EmbedBuilder()
            .setColor(embedData.Color || "#FF0000")
            .setTitle(replacePlaceholders(embedData.Title, newMessage, oldMessage, currentTime))
            .setDescription(replacePlaceholders(embedData.Description.join('\n'), newMessage, oldMessage, currentTime))
            .setFooter({ text: replacePlaceholders(embedData.Footer, newMessage, oldMessage, currentTime) });

        if (config.MessageUpdateLogs.Thumbnail) {
            embed.setThumbnail(newMessage.author.displayAvatarURL({ format: 'png', dynamic: true }));
        }

        editLogChannel.send({ embeds: [embed] });
    }

    function convertSimplePatternToRegex(simplePattern) {
        let regexPattern = simplePattern
            .replace(/\./g, '\\.')
            .replace(/\*/g, '.*');
        return new RegExp(regexPattern, 'i');
    }

    if (config.BlacklistWords.Enabled) {
        let wordBypass = config.BlacklistWords.BypassRoles.some(role => newMessage.member.roles.cache.has(role));
        let allow = config.BlacklistWords.BypassPerms.some(perm => newMessage.member.permissions.has(perm));

        if (!wordBypass && !allow) {
            const blacklistRegex = config.BlacklistWords.Patterns.map(pattern => convertSimplePatternToRegex(pattern));
            const isBlacklisted = blacklistRegex.some(regex => regex.test(newMessage.content));

            if (isBlacklisted) {
                newMessage.delete();
                newMessage.channel.send(config.BlacklistWords.Message.replace(/{user}/g, `${newMessage.author}`))
                    .then(msg => setTimeout(() => msg.delete(), 3000));
            }
        }
    }
}

function replacePlaceholders(text, newMessage, oldMessage, currentTime) {
    return text
        .replace(/{user}/g, `<@${newMessage.author.id}>`)
        .replace(/{userName}/g, newMessage.author.username)
        .replace(/{userTag}/g, newMessage.author.tag)
        .replace(/{userId}/g, newMessage.author.id)
        .replace(/{oldmessage}/g, oldMessage ? oldMessage.content : 'None')
        .replace(/{newmessage}/g, newMessage.content)
        .replace(/{channel}/g, `<#${newMessage.channel.id}>`)
        .replace(/{shorttime}/g, currentTime.format("HH:mm"))
        .replace(/{longtime}/g, currentTime.format('MMMM Do YYYY'))
        .replace(/{guildName}/g, newMessage.guild.name);
}